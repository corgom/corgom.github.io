
<?php

$renglon = $_GET["renglones"];
$colum =$_GET["columnas"];
$text = $_GET["texto"];
		
	
	function imprimir_tabla($renglon,$colum,$text)
	{   echo "<table>";
		for ($i=1; $i<=$renglon; $i++) 
		{ 
		echo "<tr>";

		   for ($y=1; $y <= $colum ; $y++) 
			{ 
			echo "<td> $text </td>";
		
			}

		echo "</tr>";
			
		}
	    echo "</table>";
	}


	 imprimir_tabla($renglon,$colum,$text);
?>

<form>

Renglones
<input type = "text" name = "renglones">
Columnas
<input type = "text" name = "columnas">
Texto
<input type = "text" name = "texto">
 <button type= "submit"> enviar </button>
</form>