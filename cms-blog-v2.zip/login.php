<?php
session_start();

if (isset($_GET["nombre"]) and (isset($_GET["password"])))
    {
    $name= $_GET["nombre"];
    $pass= $_GET["password"];
    }


function validar($usurio1,$password1)
{

$usuariovalido = "gabo";
$passwordvalido = "123";
$name = "gabo";
$pass = "123";  
       
        if ($usurio1 == "" or $password1 == "" )
        {
            $vacio = true;
        }
        else

        {

          

                    if($name == $usuariovalido and $pass ==$passwordvalido)
                    {
                    $_SESSION["usuario"] = $name;
                    header("Location: admin.php");    

                    }
                    else
                    {
                            $error = true;
                    }

        }     
    }



$validacion = validar($name= $_GET["nombre"], $pass= $_GET["password"]);
echo "$validacion";

?>




<!DOCTYPE html>

<html>

<head>
    <meta charset="UTF-8">
    <title>CMS - Blog</title>
    <link rel="stylesheet" type="text/css" href="css/obscuro.css"> 
</head>

<body>
    <img alt="header" src="img/back-header.png" width="760" height="120">
    
    <h1>Acceso</h2>
    <h2><?php
    ?></h2>

    
    



<form> 
<label> usuario:</label>
    <input type= "text" name= "nombre" value =      "<?php          
                                                        echo $name;
                                                     ?>">
    <label> password:</label>
    <input type= "password" name= "password">
    <button type= "submit"> enviar </button>

</form>
</body>

</html>
