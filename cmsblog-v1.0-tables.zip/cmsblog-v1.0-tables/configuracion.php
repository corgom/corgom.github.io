<?php
# informacion de conexion a servidor MySQL
$dbHost     = "db4free.net"; # url o direccion de la base de datos MySQL
$dbUsuario  = "examenets";
$dbPassword = "examenets";
$dbNombre   = "examenets"; # nombre de la base de datos

?>