<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>CmsBlog</title>
</head>

<body>
	<form action="install.php" method="post">
		<button type="submit">Crear tablas USUARIO y ARTICULO en Base de Datos MySQL</button>
	</form>

	<form action="drop-tables.php" method="post">
		<button type="submit">Borrar tablas USUARIO y ARTICULO de la Base de Datos MySQL</button>
	</form>
</body>

</html>