<?php
include("configuracion.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>Creando Tablas para CMS</title>
</head>

<body>
<?php

// definicion de comandos/sentencias para CREAR base de datos "cms", tablas y llenado con datos:
//$createDatabase = "CREATE DATABASE cmsblog COLLATE latin1_spanish_ci;";

$tbUsuario = "usuario";
$tbArticulo = "articulo";

$createTables = "

CREATE TABLE $tbUsuario(
id_usuario int NOT NULL PRIMARY KEY AUTO_INCREMENT,
usuario varchar(100) NOT NULL,
contrasena varchar(100) NOT NULL,
nombre varchar(100) NOT NULL
);

CREATE TABLE $tbArticulo(
id_articulo int NOT NULL PRIMARY KEY AUTO_INCREMENT,
id_usuario int NOT NULL,
fechaCreacion datetime NOT NULL,
titulo varchar(200) NOT NULL,
texto varchar(2000) NOT NULL
);

ALTER TABLE $tbArticulo
ADD FOREIGN KEY (id_usuario)
REFERENCES $tbUsuario(usuario);
";

$insertData = "
/* insercion datos en tabla USUARIO */
INSERT INTO $tbUsuario(usuario, contrasena, nombre) VALUES('cor@gmail.com', '123', 'cornelio gomez');

";

echo "<p>Preparando conexion a base de datos en host: $dbHost ...</p>";
$db = new mysqli($dbHost, $dbUsuario, $dbPassword, $dbNombre);

echo "<p>Intentando conectarse a base de datos ...</p>";
if($db->connect_errno > 0){
    die('No se puede realizar conexión a base de datos [' . $db->connect_error . ']');
}

echo "<p>Conexión exitosa</p>";

// echo "<p>Ejecutando cración de base de datos ...</p>";
// if(!$result = $db->query($createDatabase)){
//     die('Hubo un error: [' . $db->error . ']');
// }

echo "<p>Ejecutando cración de tablas ...</p>";
if(!$result = $db->multi_query($createTables)){
    die('Hubo un error: [' . $db->error . ']');
}


do { $db->use_result(); } while( $db->next_result() );

echo "<p>Insertando info inicial en tablas ...</p>";
if(!$result = $db->multi_query($insertData)){
    die('Hubo un error: [' . $db->error . ']');
}



?>




</body>

</html>