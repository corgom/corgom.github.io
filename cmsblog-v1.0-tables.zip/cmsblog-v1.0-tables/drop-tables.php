<?php
include("configuracion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>x</title>
</head>

<body>
	
	<h1>drop tables examen</h1>


<?php

$db = new mysqli($dbHost, $dbUsuario, $dbPassword, $dbNombre);

if($db->connect_errno > 0){
    die('No se puede realizar conexión a base de datos [' . $db->connect_error . ']');
}

$tables = array('articulo', 'usuario');

foreach ($tables as $table)
{
	
	$cmdSql = "DROP TABLE $table;";

	// EJECUCION DE COMANDO SQL EN MYSQL
	if($result = $db->query($cmdSql)){
		echo "<li>borrada tabla: $table<br>";
	}	
	else{
		//die('<p style="color: red; font-size: 15pt;">Hubo un error al ejecutar el comando:</p> [' . $db->error . ']');
		echo '<p style="color: red; font-size: 15pt;">Hubo un error al ejecutar el comando:</p> [' . $db->error . ']';
	}

}

?>




</body>

</html>