<ol>
    <li><a href="nuevo.html">Nuevo</a>
    <li><a href="editar.html">Editar</a>
    <li><a href="borrar.html">Borrar</a>
</ol>