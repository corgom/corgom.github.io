<ul>
    <li><a href="nuevo.php">Nuevo</a>
    <li><a href="editar.php">Editar</a>
    <li><a href="borrar.php">Borrar</a>
	<li><a href="salir.php">Salir</a>
</ul>