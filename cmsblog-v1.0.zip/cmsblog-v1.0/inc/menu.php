

<ul>
    <li><a href="index.php">Inicio</a>
    <li><a href="acerca.php">Acerca</a>
    <li><a href="login.php">Acceso</a>
</ul>

