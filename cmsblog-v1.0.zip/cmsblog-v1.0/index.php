<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>CMS - Blog Rodrigo and David</title>
    <link rel="stylesheet" type="text/css" href="css/obscuro.css"> 
</head>

<body>
	<img alt="header" src="img/back-header.png" width="760" height="120">
    
    <h1>Blog Home</h2>
    <h2>Subtitulo del blog</h2>
<?php
include "inc/menu.php"
?>
    
<h3>Titulo articulo</h3>
<p>Lorem ipsum ad his scripta blandit partiendo, eum fastidii accumsan euripidis in, eum liber hendrerit an. Qui ut wisi vocibus suscipiantur, quo dicit ridens inciderint id. Quo mundi lobortis reformidans eu, legimus senserit definiebas an eos. Eu sit tincidunt incorrupte definitionem, vis mutat affert percipit cu, eirmod consectetuer signiferumque eu per. In usu latine equidem dolores. Quo no falli viris intellegam, ut fugit veritus placerat per.</p>

</body>

</html>
